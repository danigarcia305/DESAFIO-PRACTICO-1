﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace EJER_1
{
    class lista
    {
        private nodo pri = new nodo();
        private nodo ul = new nodo();

        public static string Count { get; private set; }

        public lista()
        {
            pri = null;
            pri = null;

        }
        public void inser(string item)
        {
            nodo auxiliar = new nodo();

            auxiliar.dato = item;
            auxiliar.siguiente = null;

            if (pri== null)
            {
                pri = auxiliar;
            }
            else
            {
                nodo puntero;
                puntero = pri;
                pri = auxiliar;
                auxiliar.siguiente = puntero;
            }
        }
        public void mostrar()
        {
            nodo actua = new nodo();
            actua = pri;
            if(pri!=null)
            {
                while(actua!=null)
                {
                    Console.Write("{0} -> \t", actua.dato);
                    actua = actua.siguiente;
                }
            }else
            {
                Console.WriteLine("lista vacia");
            }
        }
        public void elimi()
        {
            nodo actu = new nodo();
            actu = pri;
            nodo ante = new nodo();
            ante = null;

            bool enco=false;
            Console.WriteLine("ingrese nodo a eliminar ");
            string bus =Console.ReadLine();
            if(pri!=null)
            {
                while(actu !=null && enco != false)
                {
                    if(actu.dato==bus)
                    {
                        Console.Write("el nodo ({0}) fue eliminado", bus);
                        if(actu==pri)
                        {
                            pri = pri.siguiente;
                        }
                        else if(actu==ul)
                        {
                            ante.siguiente = null;
                            ul = ante;
                        }
                        else
                        {
                            ante.siguiente = actu.siguiente;
                        }
                        Console.WriteLine("nodo eliminado");
                        enco = true;
                    }
                    ante = actu;
                    actu = actu.siguiente;
                }
                if (!enco)
                {
                    Console.WriteLine("no encontrado");
                }
            }else
            {
                Console.WriteLine("lista vacia");
            }
        }

        public void LongitudLista()
        {
            Console.WriteLine("\n Total de personas que se encuentran en la Lista: " + lista.Count);
        }
    }    
}