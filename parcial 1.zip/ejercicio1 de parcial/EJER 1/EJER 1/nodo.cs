﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJER_1
{
    class nodo
    {
        public string dato;
        public nodo siguiente;
        
    }
}
