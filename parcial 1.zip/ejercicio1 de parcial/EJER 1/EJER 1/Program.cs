﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJER_1
{
    class Program
    {
        static void Main(string[] args)
        {
             lista listanueva = new lista();

           
           
               int opcion = 0;

               do
               {
                   Console.Clear();
                   Console.ForegroundColor = ConsoleColor.Cyan;
                   Console.WriteLine("\n ================        Bienvenido/a        ================");
                   Console.ForegroundColor = ConsoleColor.Red;
                   Console.WriteLine("\n =                                                          =");
                   Console.WriteLine("\n = - elija una opcion...                                    =");
                   Console.WriteLine("\n =                                                          =");
                   Console.WriteLine("\n = - [1]: insertar al frente                                =");
                   Console.WriteLine("\n = - [2]: eliminar                                          =");
                   Console.WriteLine("\n = - [3]: mostrar lista                                     =");
                   Console.WriteLine("\n = - [4]: longitud de la lista                              =");
                   Console.WriteLine("\n = - [5]: salir                                             =");
                   Console.WriteLine("\n =                                                          =");
                   Console.WriteLine("\n ============================================================");
                   Console.ForegroundColor = ConsoleColor.Cyan;
                   Console.ForegroundColor = ConsoleColor.White;



                   try
                   {
                       opcion = int.Parse(Console.ReadLine());
                   }
                   catch { Console.WriteLine("\n Ingrese una opción válida"); }

                   switch (opcion)
                   {
                       case 1:
                           Console.WriteLine("\n Ingrese dato a la lista:");
                           string val = Console.ReadLine();
                           listanueva.inser(val);
                           listanueva.mostrar();
                           Console.ReadKey();
                           break;

                       case 2:
                           Console.WriteLine("\n eliminar nodo de la lista");
                           listanueva.elimi();

                           break;
                       case 3:

                           listanueva.mostrar();
                           Console.ReadKey();
                           break;
                    case 4:
                        listanueva.LongitudLista();
                        break;

                    case 5:
                           Console.WriteLine("\n saliendo del programa...");
                           Environment.Exit(0);
                           break;

                       default:
                           Console.WriteLine("\n Ingrese una opción válida");
                           break;
                   }
               } while (opcion != 4);
          



        }

        
        }
    }



