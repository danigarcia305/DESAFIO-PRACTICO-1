﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;

namespace Almacen
{
    class Program
    {





        static void Main(string[] args)
        {
            
            
            Stack pila = new Stack();



            Stack pila2 = new Stack();






    


            int lugares=0;
            int opcion ;
            
            do{
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("--------------------------------");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("|1-añadir datos                |");
                Console.WriteLine("|2-apilar                      |");
                Console.WriteLine("|3-regresar contenedores       |");
                Console.WriteLine("|4-Mostrar contenedores        |");
                Console.WriteLine("|5-retirar contenedores        |");
                Console.WriteLine("|6-salir                       |");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("--------------------------------");
                Console.ForegroundColor = ConsoleColor.White;

                opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    if (pila.Count<=4)
                    {
                        Console.WriteLine("Inserte datos al contenedor(de preferencia numeros)");
                        int dat = int.Parse(Console.ReadLine());

                        pila.Push(dat);

                        Console.WriteLine("datos ingresados correctamente");
                        Console.WriteLine("");
                        Console.WriteLine("");
                    }
                    else
                    {
                        Console.WriteLine("no se permite ingresar mas valores, contenedor lleno");
                    }
                    break;



                case 2:

                   

                        Console.ForegroundColor = ConsoleColor.Yellow;

                        Console.WriteLine("Contenedor 1 ORIGINAL");
                        Console.WriteLine("");
                        foreach (int f in pila)
                        {
                            Console.WriteLine("->{0}", f);

                        }


                        Console.WriteLine("_______________________");
                        Console.WriteLine("");
                        Console.WriteLine("Contenedor 2 ORIGINAL");
                        Console.WriteLine("");

                        foreach (int f2 in pila2)
                        {
                            Console.WriteLine("->{0}", f2);

                        }

                        Console.WriteLine("_______________________");

                        Console.WriteLine("");

                        
                        int valor;
                      
                   
                        
                         valor = Convert.ToInt32(pila.Peek());



                         if (pila.Count > 0)
                         {


                          

                             pila.Pop();


                             Console.ForegroundColor = ConsoleColor.Magenta;

                             Console.WriteLine("Contenedor 1 ALTERADO");
                             Console.WriteLine("");
                             foreach (int f in pila)
                             {
                                 Console.WriteLine("->{0}", f);

                             }


                             Console.WriteLine("_______________________");
                             Console.WriteLine("");
                         }
                            if (pila2.Count <= 4)
                            {
                                pila2.Push(valor);
                                Console.WriteLine("Contenedor 2 ALTERADO");
                                Console.WriteLine("");

                                foreach (int f2 in pila2)
                                {
                                    Console.WriteLine("->{0}", f2);

                                }

                                Console.WriteLine("_______________________");
                                Console.WriteLine("");
                            }else
                            {
                                Console.WriteLine("contenedor lleno");
                            }
                        



                      


              
                 




                    break;


                case 3:


                   

                        Console.ForegroundColor = ConsoleColor.Yellow;

                        Console.WriteLine("Contenedor 1 ORIGINAL");
                        Console.WriteLine("");
                        foreach (int f in pila)
                        {
                            Console.WriteLine("->{0}", f);

                        }


                        Console.WriteLine("_______________________");
                        Console.WriteLine("");

                        Console.WriteLine("Contenedor 2 ORIGINAL");
                        Console.WriteLine("");

                        foreach (int f2 in pila2)
                        {
                            Console.WriteLine("->{0}", f2);

                        }

                        Console.WriteLine("_______________________");
                        Console.WriteLine("");





                        int valor2;

                        valor2 = Convert.ToInt32(pila2.Peek());



                        if (pila2.Count > 0)
                        {


                            pila.Push(valor2);

                            pila2.Pop();


                            Console.ForegroundColor = ConsoleColor.Magenta;

                            Console.WriteLine("Contenedor 1 ALTERADO");
                            Console.WriteLine("");
                            foreach (int f in pila)
                            {
                                Console.WriteLine("->{0}", f);

                            }


                            Console.WriteLine("_______________________");
                            Console.WriteLine("");

                            Console.WriteLine("Contenedor 2 ALTERADO");
                            Console.WriteLine("");

                            foreach (int f2 in pila2)
                            {
                                Console.WriteLine("->{0}", f2);

                            }

                            Console.WriteLine("_______________________");
                            Console.WriteLine("");
                        }






                  


                    break;




                case 4:

                    
            Console.WriteLine("Contenedor 1");
            Console.WriteLine("");
            foreach (int f in pila)
            {
                Console.WriteLine("->{0}", f);

            }


            Console.WriteLine("_______________________");
            Console.WriteLine("");

            Console.WriteLine("Contenedor 2");

            foreach (int f2 in pila2)
            {
                Console.WriteLine("->{0}", f2);

            }

            Console.WriteLine("_______________________");
            Console.WriteLine("");



                    break;


                case 5:

                    
                    if (pila.Count != 1)
                    {
                        
                      
                        valor = Convert.ToInt32(pila.Peek());

                        valor = (int)pila.Pop();
                        Console.WriteLine("ELEMENTO -- " + valor + "--  ELIMINADO");
                    }
                    else
                    {
                        Console.WriteLine("NOSE PUEDE ELIMINAR TODOS LOS DATOS");
                    }

                    break;



            }




            if (opcion != 6)
            {
                Console.WriteLine("desea hacer otra operacion?  ");
                Console.WriteLine("");
                Console.WriteLine("SI = 1 --------- NO = cualquier tecla");
                lugares = int.Parse(Console.ReadLine());
            }

            if (opcion == 6)
            {
                Console.WriteLine("seguro que desea salir?  ");
                Console.WriteLine("");
                Console.WriteLine("SI = cualquier tecla --------- NO = 1");
                lugares = int.Parse(Console.ReadLine());



            }

            }while(lugares==1);









            Console.ReadKey();


        }
    }
}
