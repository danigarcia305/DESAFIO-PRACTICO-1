﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial_1._3
{
    class Cola1
    {
        public Nodo primero;
        public Nodo ultimo;

        public Cola1()
        {
            primero = ultimo = null;
        }

        public void Ingresar(int valor)
        {
            Console.WriteLine("\n Ingresar edad");
            Nodo aux = new Nodo();
            aux.info = valor;
            if (primero == null)
            {
                primero = ultimo = aux;
                aux.sgte = null;
            }
            else
            {
                ultimo.sgte = aux;
                aux.sgte = null;
                ultimo = aux;
            }
        }

        public void Eliminar()
        {
            if (primero == null) Console.WriteLine("Cola vacía");
            else primero = primero.sgte;
        }

        public int EliminarValor()
        {
            int valor = 0;
            if (primero == null) Console.WriteLine("Cola vacía");
            else
            {
                valor = primero.info;
                primero = primero.sgte;
            }
            return valor;
        }

        public void Mostrar()
        {
            if (primero == null) Console.WriteLine("Cola vacía");
            else
            {
                Nodo puntero;
                puntero = primero;

                do
                {
                    Console.Write("{0}\t", puntero.info);
                    puntero = puntero.sgte;
                }
                while (puntero != null);
            }
            Console.Write("\n");
        }

        public void Longitud()
        {
            for (int i = 0; i < 1; i++)
            {
                Console.WriteLine("\n Total de Personas que se encuentran en la Caja 1:  " + Cola1.Count);
                Console.WriteLine("");
            }
        }
    }
}
