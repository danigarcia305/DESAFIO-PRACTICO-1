﻿namespace Parcial_1._3
{
    class Persona
    {
        private string nombre;
        public string Nombre
        {
          get { return nombre; }
          set { nombre = value; }
        }

        private int edad;
        public int Edad
        {
            get { return edad; }
            set { edad = value; }
        }
    }
}
