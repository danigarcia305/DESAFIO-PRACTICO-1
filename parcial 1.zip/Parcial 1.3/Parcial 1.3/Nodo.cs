﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial_1._3
{
    class Nodo
    {
        public int info;
        public Nodo sgte;
    }
}
