﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial_1._3
{
    class Program
    {
        static void Main(string[] args)
        {
            Cola1 objcola = new Cola1();
            Console.WriteLine("Colocando 5 elementos en la cola");

            objcola.Ingresar(2);
            objcola.Ingresar(27);
            objcola.Ingresar(5);
            objcola.Ingresar(22);
            objcola.Ingresar(23);
            objcola.Mostrar();

            Console.WriteLine("Retirando dos elementos en cola");
            objcola.Eliminar();
            objcola.Mostrar();
            objcola.Eliminar();
            objcola.Mostrar();

            Console.WriteLine("Se va a retirar un nodo mas, con el valor de {0}", objcola.DesencolarValor());

            objcola.Mostrar();
            Console.ReadLine();
        }
    }
}
